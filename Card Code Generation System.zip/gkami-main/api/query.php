<?php
header('Content-Type: application/json; charset=utf-8');
header('X-Powered-By: 小小怪卡密系统');

// 其他代码... 